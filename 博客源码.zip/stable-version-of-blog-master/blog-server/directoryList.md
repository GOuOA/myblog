-- bin
   |-- www 项目的入口 npm start 
-- public  存放项目静态文件
   |-- images 
   |-- javascripts
   |-- stylesheets
       |-- style.css
-- routes  路由 分发请求
   |-- index.js
   |-- users.js
-- views   视图文件
        |-- error.ejs
        |-- index.ejs
-- app.js  配置文件
-- package-lock.json 控制包版本
-- package.json 包管理
