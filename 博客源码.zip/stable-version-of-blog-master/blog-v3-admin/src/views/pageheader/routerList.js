export const routerList = [
  {
    label: "首页",
    value: "Home",
    disabled: false
  },
  {
    label: "时间轴",
    value: "Archives",
    disabled: false
  },
  {
    label: "文章列表",
    value: "ArticleList",
    disabled: false
  },
  {
    label: "前端",
    value: "Front",
    disabled: false
  },
  {
    label: "后端",
    value: "Back",
    disabled: false
  },
  {
    label: "网站列表",
    value: "SiteList",
    disabled: false
  },
  {
    label: "友链",
    value: "LinkList",
    disabled: false
  },
  {
    label: "分类",
    value: "Category",
    disabled: false
  },
  {
    label: "标签",
    value: "Tag",
    disabled: false
  },
  {
    label: "相册",
    value: "PhotoAlbum",
    disabled: false
  },
  {
    label: "说说",
    value: "Talk",
    disabled: false
  },
  {
    label: "留言",
    value: "MessageList",
    disabled: false
  },
  {
    label: "留言发布/编辑",
    value: "PublishMessage",
    disabled: false
  },
  {
    label: "留言详情",
    value: "MessageDetail",
    disabled: false
  },
  {
    label: "用户中心",
    value: "UserCenter",
    disabled: false
  }
];
