export const config = {
  ENCRYPTION: true,
};
